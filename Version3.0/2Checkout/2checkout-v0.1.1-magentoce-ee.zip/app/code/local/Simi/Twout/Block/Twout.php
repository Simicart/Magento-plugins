<?php
/**
 * 
 * DISCLAIMER
 * 
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 * 
 * @category 	Simi
 * @package 	Simi_Connector
 * @copyright 	Copyright (c) 2012 
 * @license 	
 */

/**
 * Twout Model
 * 
 * @category 	
 * @package 	Twout
 * @author  	Developer
 */
class Simi_Twout_Block_Twout extends Mage_Core_Block_Template
{
	/**
	 * prepare block's layout
	 *
	 * @return Simi_Twout_Block_Twout
	 */
	public function _prepareLayout(){
		return parent::_prepareLayout();
	}
}