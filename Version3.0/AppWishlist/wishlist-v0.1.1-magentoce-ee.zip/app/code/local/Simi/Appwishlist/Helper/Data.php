<?php
/**
 *
 * DISCLAIMER
 * 
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 * 
 * @category    
 * @package     Appwishlist
 * @copyright   Copyright (c) 2012 
 * @license    
 */

/**
 * Appwishlist Helper
 * 
 * @category    
 * @package     Appwishlist
 * @author      Developer
 */
class Simi_Appwishlist_Helper_Data extends Mage_Core_Helper_Abstract
{
    
}