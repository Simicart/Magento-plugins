<?php

class Simi_Simipayu_Block_Simipayu extends Mage_Core_Block_Template
{
	public function _prepareLayout(){
		return parent::_prepareLayout();
	}
}