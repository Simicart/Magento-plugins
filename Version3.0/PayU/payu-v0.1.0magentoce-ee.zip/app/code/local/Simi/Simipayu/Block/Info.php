<?php

class Simi_Simipayu_Block_Info extends Mage_Payment_Block_Info
{
}