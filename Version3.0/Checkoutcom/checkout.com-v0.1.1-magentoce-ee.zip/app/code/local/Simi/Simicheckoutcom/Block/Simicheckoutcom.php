<?php
/**
 * 
 * DISCLAIMER
 * 
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 * 
 * @category    
 * @package     Simicheckoutcom
 * @copyright   Copyright (c) 2012 
 * @license     
 */

 /**
 * Simicheckoutcom Block
 * 
 * @category    
 * @package     Simicheckoutcom
 * @author      Developer
 */
class Simi_Simicheckoutcom_Block_Simicheckoutcom extends Mage_Core_Block_Template
{
	/**
	 * prepare block's layout
	 *
	 * @return Simi_Simicheckoutcom_Block_Simicheckoutcom
	 */
	public function _prepareLayout(){
		return parent::_prepareLayout();
	}
}