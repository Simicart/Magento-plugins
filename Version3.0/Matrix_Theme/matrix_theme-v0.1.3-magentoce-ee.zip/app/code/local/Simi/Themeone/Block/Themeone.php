<?php
/**
 * 
 * DISCLAIMER
 * 
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 * 
 * @category    
 * @package     Themeone
 * @copyright   Copyright (c) 2012 
 * @license     
 */

/**
 * Themeone Block
 * 
 * @category    
 * @package     Themeone
 * @author      Developer
 */
class Simi_Themeone_Block_Themeone extends Mage_Core_Block_Template
{
    /**
     * prepare block's layout
     *
     * @return Simi_ThemeOne_Block_Themeone
     */
    public function _prepareLayout()
    {
        return parent::_prepareLayout();
    }
}