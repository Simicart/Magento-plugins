<?php
class Magestore_Storelocator_Block_Adminhtml_Guide extends Mage_Core_Block_Template
{
    public function __construct()
    {
        parent::__construct();
    }
}