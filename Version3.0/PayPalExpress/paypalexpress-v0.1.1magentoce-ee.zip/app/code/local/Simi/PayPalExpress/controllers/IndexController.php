<?php
/**
 * 
 * DISCLAIMER
 * 
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 * 
 * @category 	
 * @package 	PayPalExpress
 * @copyright 	Copyright (c) 2012 
 * @license 	
 */

 /**
 * PayPalExpress Index Controller
 * 
 * @category 	
 * @package 	PayPalExpress
 * @author  	Developer
 */
class Simi_PayPalExpress_IndexController extends Mage_Core_Controller_Front_Action
{
	/**
	 * index action
	 */
	public function checkInstallAction(){
		echo "1";
		exit();
	}
}