<?php
/**
 * 
 * DISCLAIMER
 * 
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 * 
 * @category 	
 * @package 	Simicontact
 * @copyright 	Copyright (c) 2012 
 * @license 	
 */

 /**
 * Simicontact Controller
 * 
 * @category 	
 * @package 	Simicontact
 * @author  	Developer
 */
class Simi_Simicontact_IndexController extends Mage_Core_Controller_Front_Action
{
	public function checkInstallAction() {
        echo "1";
        exit();
    }
}