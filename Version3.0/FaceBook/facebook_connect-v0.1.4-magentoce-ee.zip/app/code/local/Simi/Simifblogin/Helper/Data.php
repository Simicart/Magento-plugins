<?php
/**
 * 
 * DISCLAIMER
 * 
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 * 
 * @category 	
 * @package 	Simifblogin
 * @copyright 	Copyright (c) 2012 
 * @license 	
 */

/**
 * Simifblogin Helper
 * 
 * @category 	
 * @package 	Simifblogin
 * @author  	Developer
 */
class Simi_Simifblogin_Helper_Data extends Mage_Core_Helper_Abstract
{
	
}