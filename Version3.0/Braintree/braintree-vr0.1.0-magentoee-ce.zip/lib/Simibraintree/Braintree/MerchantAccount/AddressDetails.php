<?php

final class Braintree_MerchantAccount_AddressDetails extends Braintree_Instance {
    protected $_attributes = array();
}
