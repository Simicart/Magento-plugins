<?php

class Simi_Simibraintree_Model_Braintree extends Mage_Payment_Model_Method_Abstract {

    protected $_code = 'simibraintree';    
    protected $_infoBlockType = 'simibraintree/braintree';
	
}
