<?php
/**
 * 
 * DISCLAIMER
 * 
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 * 
 * @category 	
 * @package 	Manalytics
 * @copyright 	Copyright (c) 2012 
 * @license 	
 */

 /**
 * Manalytics Helper
 * 
 * @category 	
 * @package 	Manalytics
 * @author  	Developer
 */
class Simi_Manalytics_Helper_Data extends Mage_Core_Helper_Abstract
{
	
}