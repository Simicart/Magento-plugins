<?php
/**
 * Magestore
 * 
 * NOTICE OF LICENSE
 * 
 * This source file is subject to the Magestore.com license that is
 * available through the world-wide-web at this URL:
 * http://www.magestore.com/license-agreement.html
 * 
 * DISCLAIMER
 * 
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 * 
 * @category    Magestore
 * @package     Magestore_ThemeOne
 * @copyright   Copyright (c) 2012 Magestore (http://www.magestore.com/)
 * @license     http://www.magestore.com/license-agreement.html
 */

/**
 * ThemeOne Index Controller
 * 
 * @category    Magestore
 * @package     Magestore_ThemeOne
 * @author      Magestore Developer
 */
class Simi_Themeone_IndexController extends Mage_Core_Controller_Front_Action
{
    /**
     * index action
     */
    public function checkInstallAction(){
		echo "1";
		exit();
	}
	
	public function installImageAction(){	
		$setup = new Mage_Core_Model_Resource_Setup();
        $installer = $setup;
        $installer->startSetup();
        $installer->run("		
				DROP TABLE IF EXISTS {$setup->getTable('themeone_images')};
				CREATE TABLE {$setup->getTable('themeone_images')} (
			   `image_id` int(11) unsigned NOT NULL auto_increment,
			  `image_type` varchar(255) NOT NULL default '',
			  `image_type_id` smallint(11) NOT NULL default '1',
			  `phone_type` varchar(255) NULL default '',
			  `options` smallint(11) NOT NULL default '1',
			  `image_name` varchar(255) NULL default '',
			  `image_delete` smallint(11) NOT NULL default '1',
			  `status` smallint(11) NOT NULL default '0',
			  `store_id` smallint(11) NOT NULL default '0',
			 PRIMARY KEY (`image_id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8;		");
        $installer->endSetup();
        echo "success";
	}
    
//    public function getOrderCategoriesAction(){
//        $data=$this->getData();
//        $information=Mage::getModel('themeone/categories_categories')->getCategories($data);
//        $this->_printDataJson($information);
//    }
//     public function getOrderSpotsAction(){
//        $data=$this->getData();
//        $information=Mage::getModel('themeone/spotproduct_spot')->getSpotProduct($data);
//        $this->_printDataJson($information);
//    }
}