<?php
/**
 * Magestore
 * 
 * NOTICE OF LICENSE
 * 
 * This source file is subject to the Magestore.com license that is
 * available through the world-wide-web at this URL:
 * http://www.magestore.com/license-agreement.html
 * 
 * DISCLAIMER
 * 
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 * 
 * @category    Magestore
 * @package     Magestore_SimiAvenue
 * @copyright   Copyright (c) 2012 Magestore (http://www.magestore.com/)
 * @license     http://www.magestore.com/license-agreement.html
 */

/**
 * SimiAvenue Helper
 * 
 * @category    Magestore
 * @package     Magestore_SimiAvenue
 * @author      Magestore Developer
 */
class Simi_SimiAvenue_Helper_Data extends Mage_Core_Helper_Abstract
{
	public function getFormFields($order_id){
		$order = new Mage_Sales_Model_Order();
		$order->loadByIncrementId($order_id);
		
		// Get CCAvenue Parameters
		// $ccavenue['action'] = Mage::getStoreConfig( 'simi_ccavenue/ccavenue/submit_url' );
		// Zend_debug::dump($order->getData());
		// die("xxx");
		$ccavenue['Order_Id'] = $order_id;
		$ccavenue['Merchant_Id'] = Mage::getStoreConfig( 'payment/simiavenue/merchant_id' );
		$ccavenue['Amount'] = round( $order->getBaseGrandTotal(), 2 );
		$ccavenue['Redirect_Url'] = Mage::getBaseUrl() . 'ccavenue/api/response';
		$ccavenue['working_key'] = Mage::getStoreConfig( 'payment/simiavenue/working_key' );		
		$ccavenue['Checksum'] = $this->getCheckSum( $ccavenue['Merchant_Id'], $ccavenue['Amount'], $ccavenue['Order_Id'], $ccavenue['Redirect_Url'], $ccavenue['working_key'] );
		
		// Retrieve order details
		$billingAddress = $order->getBillingAddress();
		$billingData = $billingAddress->getData();
		$shippingAddress = $order->getShippingAddress();
		if ( $shippingAddress )
			$shippingData = $shippingAddress->getData();
		
		$ccavenue['billing_cust_name'] = $billingData['firstname'] . ' ' . $billingData['lastname'];
		$ccavenue['billing_cust_address'] = $billingAddress->getStreet();
		$ccavenue['billing_cust_state'] = $billingAddress->getRegion();
		$ccavenue['billing_cust_country'] = Mage::getModel( 'directory/country' )->load( $billingAddress->country_id )->getName();
		$ccavenue['billing_cust_tel'] = $billingAddress->getTelephone();
		$ccavenue['billing_cust_email'] = $order->getCustomerEmail();
		if ( $shippingAddress ) {
			$ccavenue['delivery_cust_name'] = $shippingData['firstname'] . ' ' . $shippingData['lastname'];
			$ccavenue['delivery_cust_address'] = $shippingAddress->getStreet();
			$ccavenue['delivery_cust_state'] = $shippingAddress->getRegion();
			$ccavenue['delivery_cust_country'] = Mage::getModel( 'directory/country' )->load( $shippingAddress->country_id )->getName();
			$ccavenue['delivery_cust_tel'] = $shippingAddress->getTelephone();
			$ccavenue['delivery_city'] = $shippingAddress->getCity();
			$ccavenue['delivery_zip'] = $shippingAddress->getPostcode();
		}
		else {
			$ccavenue['delivery_cust_name'] = '';
			$ccavenue['delivery_cust_address'] = '';
			$ccavenue['delivery_cust_state'] = '';
			$ccavenue['delivery_cust_country'] = '';
			$ccavenue['delivery_cust_tel'] = '';
			$ccavenue['delivery_city'] = '';
			$ccavenue['delivery_zip'] = '';
		}
		$ccavenue['Merchant_Param'] = '';
		$ccavenue['billing_city'] = $billingAddress->getCity();
		$ccavenue['billing_zip'] = $billingAddress->getPostcode();
		$ccavenue['billing_cust_notes'] = '';
		// Zend_debug::dump($ccavenue);die();
		$url = Mage::getStoreConfig( 'payment/simiavenue/submit_url' ). "?";
		foreach ($ccavenue as $key => $value){	
			$url .= $key ."=". $value ."&"; 
		}
		
		return $url;		
	}
	
	/* -------------------- DO NOT EDIT BELOW THIS LINE : CCAVENUE FUNCTIONS -------------------- */
	private function getchecksum($merchant_id, $amount, $order_id, $url, $working_key) {
		$str = "$merchant_id|$order_id|$amount|$url|$working_key";
		$adler = 1;
		$adler = $this->adler32($adler,$str);
		return $adler;
	}
	
	private function verifychecksum($merchant_id, $order_id, $amount, $auth_desc, $checksum, $working_key) {
		$str = "$merchant_id|$order_id|$amount|$auth_desc|$working_key";
		$adler = 1;
		$adler = $this->adler32($adler,$str);
		
		if($adler == $checksum)
			return "true" ;
		else
			return "false" ;
	}
	
	private function adler32($adler , $str) {
		$BASE =  65521 ;
	
		$s1 = $adler & 0xffff ;
		$s2 = ($adler >> 16) & 0xffff;
		for($i = 0 ; $i < strlen($str) ; $i++)
		{
			$s1 = ($s1 + Ord($str[$i])) % $BASE ;
			$s2 = ($s2 + $s1) % $BASE ;
	
		}
		return $this->leftshift($s2 , 16) + $s1;
	}
	
	private function leftshift($str , $num) {
	
		$str = DecBin($str);
	
		for( $i = 0 ; $i < (64 - strlen($str)) ; $i++)
			$str = "0".$str ;
	
		for($i = 0 ; $i < $num ; $i++) 
		{
			$str = $str."0";
			$str = substr($str , 1 ) ;
		}
		return $this->cdec($str) ;
	}
	
	private function cdec($num) {
	
		for ($n = 0 ; $n < strlen($num) ; $n++)
		{
		   $temp = $num[$n] ;
		   $dec =  $dec + $temp*pow(2 , strlen($num) - $n - 1);
		}
	
		return $dec;
	}
	/* -------------------- DO NOT EDIT ABOVE THIS LINE : CCAVENUE FUNCTIONS -------------------- */
}