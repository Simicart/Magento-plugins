<?php
/**
 * Magestore
 * 
 * NOTICE OF LICENSE
 * 
 * This source file is subject to the Magestore.com license that is
 * available through the world-wide-web at this URL:
 * http://www.magestore.com/license-agreement.html
 * 
 * DISCLAIMER
 * 
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 * 
 * @category    Magestore
 * @package     Magestore_SimiAvenue
 * @copyright   Copyright (c) 2012 Magestore (http://www.magestore.com/)
 * @license     http://www.magestore.com/license-agreement.html
 */

/**
 * SimiAvenue Index Controller
 * 
 * @category    Magestore
 * @package     Magestore_SimiAvenue
 * @author      Magestore Developer
 */
class Simi_SimiAvenue_ApiController extends Simi_Connector_Controller_Action
{	
	
	public function indexAction(){
	
	}
	
	
	public function responseAction(){
		if($this->getRequest()->isPost()) {
			// Retrieve POST Values
			$working_key = Mage::getStoreConfig( 'payment/simiavenue/working_key' );
			$merchant_id = $this->getRequest()->getPost( 'Merchant_Id' );
			$amount = $this->getRequest()->getPost( 'Amount' );
			$order_id = $this->getRequest()->getPost( 'Order_Id' );
			$merchant_param = $this->getRequest()->getPost( 'Merchant_Param' );
			$checksum = $this->getRequest()->getPost( 'Checksum' );
			$auth_desc = $this->getRequest()->getPost( 'AuthDesc' );
			$card_category = $this->getRequest()->getPost( 'card_category' );
			$bank_name = $this->getRequest()->getPost( 'bank_name' );

			// Check whether AuthQuery is required
			if ( Mage::getStoreConfig( 'payment/simiavenue/enable_auth_query' ) ) {
				// Prepare cURL request
				$ch = curl_init();
				$post_data = 'Merchant_Id=' . Mage::getStoreConfig( 'payment/simiavenue/merchant_id' ) . '&Order_Id=' . $order_id;
				curl_setopt( $ch, CURLOPT_URL, 'https://www.ccavenue.com/servlet/new_txn.OrderStatusTracker' );
				curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
				curl_setopt( $ch, CURLOPT_HEADER, false );
				curl_setopt( $ch, CURLOPT_POST, count( $post_data ) );
				curl_setopt( $ch, CURLOPT_POSTFIELDS, $post_data ) ;
				
				// Run cURL request
				$order_details = curl_exec( $ch );

				// Close cURL request
				curl_close( $ch );

				// Check for error
				if ( stripos( $order_details, 'error=' ) !== false ) {
					$auth_desc = 'AuthQuery!';
				}
				else {
					// No error, check for validity
					parse_str( $order_details, $order_details );
					if ( ! isset( $order_details['Order_Id'] ) || ! isset( $order_details['AuthDesc'] ) || $order_details['Order_Id'] != $merchant_id . '-' . $order_id || $order_details['AuthDesc'] != $auth_desc )
						$auth_desc = 'AuthQuery!';
				}
			}					
									
			Mage::getModel( 'simiavenue/simiavenue' )
				->setMerchantId( $merchant_id )
				->setAmount( $amount )
				->setOrderId( $order_id )
				->setMerchantParam( $merchant_param )
				->setChecksum( $checksum )
				->setAuthdesc( $auth_desc )			
				->setCardCategory( $card_category )
				->setBankName( $bank_name )
				->save();
					
			$checksum = $this->verifyChecksum( $merchant_id, $order_id, $amount, $auth_desc, $checksum, $working_key );
			
			// Check response and take appropriate actions
			if ( $checksum == "true" && $auth_desc == "Y" )	{
				 // Payment was successful, so update the order's state, send order email and move to the success page
				$order = Mage::getModel( 'sales/order' );
				$order->loadByIncrementId( $order_id );
				$order->setState( Mage_Sales_Model_Order::STATE_PROCESSING, true, 'CCAvenue has authorized the payment.' );
				
				$order->sendNewOrderEmail();
				$order->setEmailSent( true );
				
				$order->save();
			
				Mage::getSingleton( 'checkout/session' )->unsQuoteId();
				
				Mage_Core_Controller_Varien_Action::_redirect( 'checkout/onepage/success', array( '_secure' => true ) );
			}
			else if($checksum == "true" && $auth_desc == "B") {
				// Payment was successful as a 'Batch Processing' order. Status of such payments can only be determined after some time
				$this->reviewAction();
				Mage_Core_Controller_Varien_Action::_redirect( 'checkout/onepage/review', array( '_secure' => true) );
			}
			else if($checksum == "true" && $auth_desc == "N") {
				// CCAvenue has declined the payment, so cancel the order and redirect to fail page
				$this->cancelAction();
				Mage_Core_Controller_Varien_Action::_redirect( 'checkout/onepage/failure', array( '_secure' => true) );
			}
			else {
				// There is a serious problem in getting a response from CCAvenue
				$this->cancelAction();
				Mage_Core_Controller_Varien_Action::_redirect( 'checkout/onepage/failure', array( '_secure ' => true) );
			}
		}
		else
			Mage_Core_Controller_Varien_Action::_redirect( 'simiavenue/api/index', array( '_secure ' => true) );
	}
	
	public function cancelAction() {
		if ( Mage::getSingleton( 'checkout/session' )->getLastRealOrderId() ) {
			$order = Mage::getModel( 'sales/order' )->loadByIncrementId( Mage::getSingleton( 'checkout/session' )->getLastRealOrderId() );
			if ( $order->getId() ) {
				// Flag the order as 'cancelled' and save it
				$order->cancel()->setState( Mage_Sales_Model_Order::STATE_CANCELED, true, 'CCAvenue has declined the payment.' )->save();
			}
		}
	}
	
	public function reviewAction() {
		if ( Mage::getSingleton( 'checkout/session' )->getLastRealOrderId() ) {
			$order = Mage::getModel( 'sales/order' )->loadByIncrementId( Mage::getSingleton( 'checkout/session' )->getLastRealOrderId() );
			if ( $order->getId() ) {
				// Flag the order as 'payment review' and save it
				$order->setState( Mage_Sales_Model_Order::STATE_PAYMENT_REVIEW, true, 'CCAvenue has sent AuthDesc as B.' );
				$order->save();
			}
		}
	}
	
	/* -------------------- DO NOT EDIT BELOW THIS LINE : CCAVENUE FUNCTIONS -------------------- */
	private function getchecksum($merchant_id, $amount, $order_id, $url, $working_key) {
		$str = "$merchant_id|$order_id|$amount|$url|$working_key";
		$adler = 1;
		$adler = $this->adler32($adler,$str);
		return $adler;
	}
	
	private function verifychecksum($merchant_id, $order_id, $amount, $auth_desc, $checksum, $working_key) {
		$str = "$merchant_id|$order_id|$amount|$auth_desc|$working_key";
		$adler = 1;
		$adler = $this->adler32($adler,$str);
		
		if($adler == $checksum)
			return "true" ;
		else
			return "false" ;
	}
	
	private function adler32($adler , $str) {
		$BASE =  65521 ;
	
		$s1 = $adler & 0xffff ;
		$s2 = ($adler >> 16) & 0xffff;
		for($i = 0 ; $i < strlen($str) ; $i++)
		{
			$s1 = ($s1 + Ord($str[$i])) % $BASE ;
			$s2 = ($s2 + $s1) % $BASE ;
	
		}
		return $this->leftshift($s2 , 16) + $s1;
	}
	
	private function leftshift($str , $num) {
	
		$str = DecBin($str);
	
		for( $i = 0 ; $i < (64 - strlen($str)) ; $i++)
			$str = "0".$str ;
	
		for($i = 0 ; $i < $num ; $i++) 
		{
			$str = $str."0";
			$str = substr($str , 1 ) ;
		}
		return $this->cdec($str) ;
	}
	
	private function cdec($num) {
	
		for ($n = 0 ; $n < strlen($num) ; $n++)
		{
		   $temp = $num[$n] ;
		   $dec =  $dec + $temp*pow(2 , strlen($num) - $n - 1);
		}
	
		return $dec;
	}
	/* -------------------- DO NOT EDIT ABOVE THIS LINE : CCAVENUE FUNCTIONS -------------------- */
}