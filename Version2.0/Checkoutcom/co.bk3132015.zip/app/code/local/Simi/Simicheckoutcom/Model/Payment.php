<?php

class Simi_Simicheckoutcom_Model_Payment extends Mage_Payment_Model_Method_Abstract 
{

    protected $_code = 'simicheckoutcom';    
    protected $_infoBlockType = 'simicheckoutcom/payment';
}
